import java.nio.file.*;
import java.io.IOException;
import java.nio.file.attribute.FileTime;
import java.util.Scanner;

public class Actividad1 {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        System.out.print("Ingrese la ruta de un archivo o directorio: ");
        String ruta = sc.nextLine();
        Path path = Paths.get(ruta);
        try {
            System.out.println("\nInformación del archivo o directorio:");
            System.out.println("Nombre: " + path.getFileName());
            System.out.println("Ruta absoluta: " + path.toAbsolutePath());
            System.out.println("¿Es directorio?: " + Files.isDirectory(path));
            System.out.println("¿Es ruta absoluta?: " + path.isAbsolute());
            System.out.println("Última modificación: " + Files.getLastModifiedTime(path));
            System.out.println("Tamaño (bytes): " + Files.size(path));
        } catch (IOException e) {
            System.out.println("Error al obtener información: " + e.getMessage());
        }
        sc.close();
    }
}

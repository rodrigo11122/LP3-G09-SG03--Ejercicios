import java.io.FileWriter;
import java.io.IOException;
import java.util.Scanner;

public class Actividad2 {
    public static void main(String[] args) {
        try (Scanner sc = new Scanner(System.in);
             FileWriter fw = new FileWriter("datos.txt", true)) {
            System.out.println("Ingrese texto (escriba 'salir' para finalizar):");
            while (true) {
                String linea = sc.nextLine();
                if (linea.equalsIgnoreCase("salir")) break;
                fw.write(linea + System.lineSeparator());
            }
            System.out.println("Datos guardados correctamente en datos.txt");
        } catch (IOException e) {
            System.out.println("Error de escritura: " + e.getMessage());
        }
    }
}

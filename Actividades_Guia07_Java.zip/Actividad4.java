import javax.swing.*;
import java.io.*;

public class Actividad4 {
    public static void main(String[] args) {
        JFrame frame = new JFrame("Visualizador de Archivo");
        JTextArea textArea = new JTextArea(20, 50);
        JScrollPane scroll = new JScrollPane(textArea);
        frame.add(scroll);
        frame.pack();
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setVisible(true);

        try (FileInputStream fis = new FileInputStream("TestFile.java")) {
            int c;
            while ((c = fis.read()) != -1) {
                textArea.append(String.valueOf((char) c));
            }
        } catch (IOException e) {
            textArea.setText("Error al leer el archivo: " + e.getMessage());
        }
    }
}

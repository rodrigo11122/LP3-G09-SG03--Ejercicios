import java.io.*;
import java.util.*;

class Persona {
    String nombre;
    String telefono;
    String direccion;

    Persona(String n, String t, String d) {
        this.nombre = n;
        this.telefono = t;
        this.direccion = d;
    }

    public String toString() {
        return nombre + " - " + telefono + " - " + direccion;
    }
}

public class Actividad5 {
    public static void main(String[] args) {
        List<Persona> agenda = new ArrayList<>();
        try (BufferedReader br = new BufferedReader(new FileReader("agenda.txt"))) {
            String linea;
            while ((linea = br.readLine()) != null) {
                String[] datos = linea.split(",");
                if (datos.length == 3)
                    agenda.add(new Persona(datos[0], datos[1], datos[2]));
            }
        } catch (IOException e) {
            System.out.println("Error al leer el archivo: " + e.getMessage());
            return;
        }

        Scanner sc = new Scanner(System.in);
        System.out.print("Ingrese un nombre para buscar: ");
        String nombre = sc.nextLine();
        boolean encontrado = false;
        for (Persona p : agenda) {
            if (p.nombre.equalsIgnoreCase(nombre)) {
                System.out.println("Contacto encontrado: " + p);
                encontrado = true;
                break;
            }
        }
        if (!encontrado) System.out.println("No se encontró el contacto.");
        sc.close();
    }
}

import java.io.*;
import java.util.*;

class Fecha implements Serializable {
    int dia, mes, anio;
    public Fecha(int d, int m, int a) {
        dia = d; mes = m; anio = a;
    }
    public String toString() {
        return dia + "/" + mes + "/" + anio;
    }
}

class Persona2 implements Serializable {
    String nombre;
    public Persona2(String n) { nombre = n; }
    public String toString() { return nombre; }
}

class Alumno extends Persona2 {
    Fecha fechaNacimiento;
    public Alumno(String n, Fecha f) {
        super(n);
        this.fechaNacimiento = f;
    }
    public String toString() {
        return "Alumno: " + nombre + " - Nacimiento: " + fechaNacimiento;
    }
}

public class Actividad6 {
    public static void main(String[] args) {
        try (ObjectOutputStream oos = new ObjectOutputStream(new FileOutputStream("alumnos.dat"))) {
            oos.writeObject(new Alumno("Carlos", new Fecha(10, 5, 2000)));
            oos.writeObject(new Alumno("Ana", new Fecha(12, 8, 1999)));
            oos.writeObject(new Alumno("Luis", new Fecha(25, 11, 2001)));
            System.out.println("Objetos serializados correctamente.");
        } catch (IOException e) {
            System.out.println("Error: " + e.getMessage());
        }
    }
}

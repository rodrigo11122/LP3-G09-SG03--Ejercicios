import javax.swing.*;
import java.io.File;

public class Actividad7 {
    public static void main(String[] args) {
        JFileChooser fileChooser = new JFileChooser();
        int result = fileChooser.showOpenDialog(null);
        if (result == JFileChooser.APPROVE_OPTION) {
            File archivo = fileChooser.getSelectedFile();
            System.out.println("Archivo seleccionado: " + archivo.getAbsolutePath());
        } else {
            System.out.println("No se seleccionó ningún archivo.");
        }
    }
}

import java.io.*;
import java.util.*;

public class Ejercicio2_NuevasFuncionalidades extends Ejercicio1_GestorPersonajes {
    // Este ejemplo se integraría al Gestor principal para filtrar, ordenar y mostrar estadísticas.
    // Se dejan comentarios para indicar mejoras.

    // Posibles nuevas funciones:
    // 1. Filtrar personajes por atributo (vida, ataque, etc.)
    // 2. Mostrar estadísticas promedio.
    // 3. Importar personajes desde otro archivo.
}

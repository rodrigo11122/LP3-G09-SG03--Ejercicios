import java.sql.*;
import java.util.Scanner;

public class MainSQLite {
    private static final String URL = "jdbc:sqlite:basedatos.db";
    private static final String CLAVE = "1234"; // Clave para confirmar operaciones

    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        try {
            Class.forName("org.sqlite.JDBC");
            Connection con = DriverManager.getConnection(URL);
            con.setAutoCommit(false);
            Statement stmt = con.createStatement();

            // Crear tabla
            stmt.execute("CREATE TABLE IF NOT EXISTS personas (" +
                         "id INTEGER PRIMARY KEY AUTOINCREMENT," +
                         "nombre TEXT NOT NULL," +
                         "edad INTEGER," +
                         "correo TEXT)");
            System.out.println("Tabla creada o ya existente.\n");

            int opcion;
            do {
                System.out.println("---- MENÚ ----");
                System.out.println("1. Insertar registro");
                System.out.println("2. Mostrar registros");
                System.out.println("3. Actualizar registro");
                System.out.println("4. Eliminar registro");
                System.out.println("5. Salir");
                System.out.print("Seleccione una opción: ");
                opcion = sc.nextInt();
                sc.nextLine();

                switch (opcion) {
                    case 1 -> insertar(con, sc);
                    case 2 -> mostrar(con);
                    case 3 -> actualizar(con, sc);
                    case 4 -> eliminar(con, sc);
                    case 5 -> System.out.println("Saliendo...");
                    default -> System.out.println("Opción inválida.");
                }
            } while (opcion != 5);

            con.close();
            sc.close();

        } catch (Exception e) {
            System.out.println("Error: " + e.getMessage());
        }
    }

    private static void insertar(Connection con, Scanner sc) throws SQLException {
        System.out.print("Ingrese nombre: ");
        String nombre = sc.nextLine();
        System.out.print("Ingrese edad: ");
        int edad = sc.nextInt();
        sc.nextLine();
        System.out.print("Ingrese correo: ");
        String correo = sc.nextLine();

        PreparedStatement ps = con.prepareStatement("INSERT INTO personas(nombre, edad, correo) VALUES(?,?,?)");
        ps.setString(1, nombre);
        ps.setInt(2, edad);
        ps.setString(3, correo);
        ps.executeUpdate();

        confirmarOperacion(con, sc);
    }

    private static void mostrar(Connection con) throws SQLException {
        Statement stmt = con.createStatement();
        ResultSet rs = stmt.executeQuery("SELECT * FROM personas");
        System.out.println("\n--- LISTA DE PERSONAS ---");
        while (rs.next()) {
            System.out.println(rs.getInt("id") + " | " +
                               rs.getString("nombre") + " | " +
                               rs.getInt("edad") + " | " +
                               rs.getString("correo"));
        }
        System.out.println("---------------------------\n");
    }

    private static void actualizar(Connection con, Scanner sc) throws SQLException {
        System.out.print("Ingrese ID a actualizar: ");
        int id = sc.nextInt();
        sc.nextLine();
        System.out.print("Nuevo nombre: ");
        String nombre = sc.nextLine();
        System.out.print("Nueva edad: ");
        int edad = sc.nextInt();
        sc.nextLine();
        System.out.print("Nuevo correo: ");
        String correo = sc.nextLine();

        PreparedStatement ps = con.prepareStatement(
            "UPDATE personas SET nombre=?, edad=?, correo=? WHERE id=?");
        ps.setString(1, nombre);
        ps.setInt(2, edad);
        ps.setString(3, correo);
        ps.setInt(4, id);
        ps.executeUpdate();

        confirmarOperacion(con, sc);
    }

    private static void eliminar(Connection con, Scanner sc) throws SQLException {
        System.out.print("Ingrese ID a eliminar: ");
        int id = sc.nextInt();
        sc.nextLine();

        PreparedStatement ps = con.prepareStatement("DELETE FROM personas WHERE id=?");
        ps.setInt(1, id);
        ps.executeUpdate();

        confirmarOperacion(con, sc);
    }

    private static void confirmarOperacion(Connection con, Scanner sc) throws SQLException {
        System.out.print("Ingrese clave para confirmar los cambios: ");
        String clave = sc.nextLine();
        if (clave.equals(CLAVE)) {
            con.commit();
            System.out.println("Operación confirmada.\n");
        } else {
            con.rollback();
            System.out.println("Clave incorrecta. Cambios revertidos.\n");
        }
    }
}

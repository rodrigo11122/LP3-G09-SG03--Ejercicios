import java.sql.*;
import java.util.*;

class Producto {
    int id;
    String nombre;
    double precio;
    int stock;

    public Producto(int id, String nombre, double precio, int stock) {
        this.id = id;
        this.nombre = nombre;
        this.precio = precio;
        this.stock = stock;
    }
}

public class GestorProductos {

    public static void menuConsultas(Connection conexion, Scanner sc) throws SQLException {
        List<Producto> productos = cargarProductos(conexion);
        if (productos.isEmpty()) {
            System.out.println("No hay productos registrados en la base de datos.");
            return;
        }

        int opcion;
        do {
            System.out.println("\n===== MENÚ DE CONSULTAS =====");
            System.out.println("1. Mostrar todos los productos");
            System.out.println("2. Filtrar por precio mínimo");
            System.out.println("3. Ordenar por precio");
            System.out.println("4. Limitar cantidad de resultados");
            System.out.println("5. Volver al menú principal");
            System.out.print("Seleccione una opción: ");
            opcion = sc.nextInt();
            sc.nextLine();

            switch (opcion) {
                case 1 -> mostrar(productos);
                case 2 -> filtrarPorPrecio(productos, sc);
                case 3 -> ordenarPorPrecio(productos, sc);
                case 4 -> limitarResultados(productos, sc);
                case 5 -> System.out.println("Volviendo al menú principal...");
                default -> System.out.println("Opción no válida.");
            }

        } while (opcion != 5);
    }

    private static List<Producto> cargarProductos(Connection conexion) throws SQLException {
        List<Producto> lista = new ArrayList<>();
        Statement stmt = conexion.createStatement();
        ResultSet rs = stmt.executeQuery("SELECT * FROM productos");
        while (rs.next()) {
            lista.add(new Producto(
                rs.getInt("id"),
                rs.getString("nombre"),
                rs.getDouble("precio"),
                rs.getInt("stock")
            ));
        }
        rs.close();
        stmt.close();
        return lista;
    }

    private static void mostrar(List<Producto> lista) {
        System.out.println("\n===== PRODUCTOS =====");
        for (Producto p : lista) {
            System.out.printf("ID: %d | %s | Precio: %.2f | Stock: %d\n", p.id, p.nombre, p.precio, p.stock);
        }
    }

    private static void filtrarPorPrecio(List<Producto> lista, Scanner sc) {
        System.out.print("Ingrese el precio mínimo: ");
        double min = sc.nextDouble();
        sc.nextLine();
        System.out.println("\nProductos con precio mayor o igual a " + min + ":");
        lista.stream()
             .filter(p -> p.precio >= min)
             .forEach(p -> System.out.printf("ID: %d | %s | %.2f | Stock: %d\n", p.id, p.nombre, p.precio, p.stock));
    }

    private static void ordenarPorPrecio(List<Producto> lista, Scanner sc) {
        System.out.print("¿Desea ordenar de forma ascendente (A) o descendente (D)? ");
        String orden = sc.nextLine().trim().toUpperCase();
        lista.sort((a, b) -> orden.equals("A") ? Double.compare(a.precio, b.precio) : Double.compare(b.precio, a.precio));
        mostrar(lista);
    }

    private static void limitarResultados(List<Producto> lista, Scanner sc) {
        System.out.print("Ingrese la cantidad máxima de productos a mostrar: ");
        int limite = sc.nextInt();
        sc.nextLine();
        lista.stream().limit(limite).forEach(p ->
            System.out.printf("ID: %d | %s | %.2f | Stock: %d\n", p.id, p.nombre, p.precio, p.stock));
    }
}

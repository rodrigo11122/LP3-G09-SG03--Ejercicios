import java.sql.*;
import java.util.Scanner;

public class Principal {

    private static final String URL = "jdbc:sqlite:tienda.db";
    private static final String CLAVE_SEGURIDAD = "1234";

    public static void main(String[] args) {
        try {
            Class.forName("org.sqlite.JDBC");
            Connection conexion = DriverManager.getConnection(URL);
            crearTablaSiNoExiste(conexion);

            Scanner sc = new Scanner(System.in);
            int opcion;

            do {
                System.out.println("\n===== MENÚ PRINCIPAL =====");
                System.out.println("1. Ingresar producto");
                System.out.println("2. Actualizar producto");
                System.out.println("3. Eliminar producto");
                System.out.println("4. Mostrar productos");
                System.out.println("5. Consultas desde Java");
                System.out.println("6. Salir");
                System.out.print("Seleccione una opción: ");
                opcion = sc.nextInt();
                sc.nextLine();

                switch (opcion) {
                    case 1 -> insertarProducto(conexion, sc);
                    case 2 -> actualizarProducto(conexion, sc);
                    case 3 -> eliminarProducto(conexion, sc);
                    case 4 -> mostrarProductos(conexion);
                    case 5 -> GestorProductos.menuConsultas(conexion, sc);
                    case 6 -> System.out.println("Saliendo del programa...");
                    default -> System.out.println("Opción no válida");
                }
            } while (opcion != 6);

            conexion.close();
            sc.close();

        } catch (Exception e) {
            System.out.println("Error: " + e.getMessage());
        }
    }

    private static void crearTablaSiNoExiste(Connection conexion) throws SQLException {
        Statement stmt = conexion.createStatement();
        stmt.execute("""
            CREATE TABLE IF NOT EXISTS productos (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                nombre TEXT NOT NULL,
                precio REAL NOT NULL,
                stock INTEGER NOT NULL
            )
        """);
        stmt.close();
    }

    private static void insertarProducto(Connection conexion, Scanner sc) throws SQLException {
        conexion.setAutoCommit(false);

        System.out.print("Ingrese nombre del producto: ");
        String nombre = sc.nextLine();
        System.out.print("Ingrese precio: ");
        double precio = sc.nextDouble();
        System.out.print("Ingrese stock: ");
        int stock = sc.nextInt();
        sc.nextLine();

        PreparedStatement ps = conexion.prepareStatement("INSERT INTO productos(nombre, precio, stock) VALUES (?, ?, ?)");
        ps.setString(1, nombre);
        ps.setDouble(2, precio);
        ps.setInt(3, stock);

        ps.executeUpdate();
        confirmarOperacion(conexion, sc, "Producto ingresado correctamente.");
        ps.close();
    }

    private static void actualizarProducto(Connection conexion, Scanner sc) throws SQLException {
        conexion.setAutoCommit(false);

        System.out.print("Ingrese ID del producto a actualizar: ");
        int id = sc.nextInt();
        sc.nextLine();
        System.out.print("Nuevo nombre: ");
        String nombre = sc.nextLine();
        System.out.print("Nuevo precio: ");
        double precio = sc.nextDouble();
        System.out.print("Nuevo stock: ");
        int stock = sc.nextInt();
        sc.nextLine();

        PreparedStatement ps = conexion.prepareStatement("UPDATE productos SET nombre=?, precio=?, stock=? WHERE id=?");
        ps.setString(1, nombre);
        ps.setDouble(2, precio);
        ps.setInt(3, stock);
        ps.setInt(4, id);

        int filas = ps.executeUpdate();
        if (filas > 0)
            confirmarOperacion(conexion, sc, "Producto actualizado correctamente.");
        else
            System.out.println("No se encontró el producto con ese ID.");

        ps.close();
    }

    private static void eliminarProducto(Connection conexion, Scanner sc) throws SQLException {
        conexion.setAutoCommit(false);

        System.out.print("Ingrese ID del producto a eliminar: ");
        int id = sc.nextInt();
        sc.nextLine();

        PreparedStatement ps = conexion.prepareStatement("DELETE FROM productos WHERE id=?");
        ps.setInt(1, id);
        int filas = ps.executeUpdate();

        if (filas > 0)
            confirmarOperacion(conexion, sc, "Producto eliminado correctamente.");
        else
            System.out.println("No se encontró el producto con ese ID.");

        ps.close();
    }

    private static void mostrarProductos(Connection conexion) throws SQLException {
        Statement stmt = conexion.createStatement();
        ResultSet rs = stmt.executeQuery("SELECT * FROM productos");

        System.out.println("\n===== LISTA DE PRODUCTOS =====");
        while (rs.next()) {
            System.out.printf("ID: %d | Nombre: %s | Precio: %.2f | Stock: %d\n",
                    rs.getInt("id"),
                    rs.getString("nombre"),
                    rs.getDouble("precio"),
                    rs.getInt("stock"));
        }

        rs.close();
        stmt.close();
    }

    private static void confirmarOperacion(Connection conexion, Scanner sc, String mensajeExito) throws SQLException {
        System.out.print("Ingrese la clave para confirmar los cambios: ");
        String clave = sc.nextLine();

        if (clave.equals(CLAVE_SEGURIDAD)) {
            conexion.commit();
            System.out.println(mensajeExito);
        } else {
            conexion.rollback();
            System.out.println("Clave incorrecta. Cambios revertidos.");
        }

        conexion.setAutoCommit(true);
    }
}

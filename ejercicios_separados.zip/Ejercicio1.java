// Ejercicio1.java
// Este archivo contiene solo la explicación del Ejercicio 1.

public class Ejercicio1 {
    public static void main(String[] args) {
        System.out.println("Ejercicio 1: Revisa las explicaciones dentro del archivo.");
    }

    /*
       EJERCICIO 1:
       Investiga herramientas visuales para crear GUIs con arrastrar y soltar (NetBeans, Eclipse WindowBuilder, IntelliJ GUI Designer).

       - Proceso:
            * Se arrastran componentes a un formulario.
            * El IDE genera automáticamente el código.
            * El usuario solo programa la lógica de eventos.

       - Ventajas:
            * Rápido de diseñar.
            * Vista previa inmediata.
            * No necesitas conocer los layouts a profundidad.

       - Desventajas:
            * Código generado difícil de leer o editar.
            * Poca flexibilidad comparada con escribir código manualmente.
            * Dependencia del IDE.
    */
}

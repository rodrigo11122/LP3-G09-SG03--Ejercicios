// Ejercicio2.java
// Implementación GUI Swing para compra de pasajes.

import javax.swing.*;
import java.awt.*;
import java.awt.event.*;

public class Ejercicio2 {

    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> new VentanaCompraPasaje());
    }
}

class VentanaCompraPasaje extends JFrame {

    private JTextField txtNombre, txtDNI, txtFecha;
    private JCheckBox chkAudifonos, chkManta, chkRevistas;
    private JRadioButton rbPrimerPiso, rbSegundoPiso;
    private JComboBox<String> cbOrigen, cbDestino;
    private JList<String> listaServicio;
    private JButton btnMostrar, btnLimpiar;

    public VentanaCompraPasaje() {
        setTitle("Compra de Pasajes - GUI Swing");
        setSize(500, 500);
        setLocationRelativeTo(null);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLayout(new GridLayout(9, 1));

        JPanel p1 = new JPanel(new GridLayout(3, 2));
        p1.add(new JLabel("Nombre:"));
        txtNombre = new JTextField();
        p1.add(txtNombre);

        p1.add(new JLabel("DNI:"));
        txtDNI = new JTextField();
        p1.add(txtDNI);

        p1.add(new JLabel("Fecha de Viaje:"));
        txtFecha = new JTextField("dd/mm/aaaa");
        p1.add(txtFecha);
        add(p1);

        JPanel p2 = new JPanel();
        chkAudifonos = new JCheckBox("Audífonos");
        chkManta = new JCheckBox("Manta");
        chkRevistas = new JCheckBox("Revistas");
        p2.add(chkAudifonos);
        p2.add(chkManta);
        p2.add(chkRevistas);
        add(new JLabel("Servicios adicionales:"));
        add(p2);

        JPanel p3 = new JPanel();
        rbPrimerPiso = new JRadioButton("1er Piso");
        rbSegundoPiso = new JRadioButton("2do Piso");
        ButtonGroup grupoPiso = new ButtonGroup();
        grupoPiso.add(rbPrimerPiso);
        grupoPiso.add(rbSegundoPiso);
        rbPrimerPiso.setSelected(true);
        p3.add(rbPrimerPiso);
        p3.add(rbSegundoPiso);
        add(new JLabel("Seleccione el piso:"));
        add(p3);

        JPanel p4 = new JPanel();
        cbOrigen = new JComboBox<>(new String[]{"Lima", "Arequipa", "Cusco", "Puno"});
        cbDestino = new JComboBox<>(new String[]{"Lima", "Arequipa", "Cusco", "Puno"});
        p4.add(new JLabel("Origen:"));
        p4.add(cbOrigen);
        p4.add(new JLabel("Destino:"));
        p4.add(cbDestino);
        add(p4);

        JPanel p5 = new JPanel();
        listaServicio = new JList<>(new String[]{"Económico", "Standard", "VIP"});
        listaServicio.setVisibleRowCount(3);
        p5.add(new JLabel("Calidad de servicio:"));
        p5.add(new JScrollPane(listaServicio));
        add(p5);

        JPanel p6 = new JPanel();
        btnMostrar = new JButton("Mostrar Resumen");
        btnLimpiar = new JButton("Limpiar");
        p6.add(btnMostrar);
        p6.add(btnLimpiar);
        add(p6);

        btnMostrar.addActionListener(e -> mostrarResumen());
        btnLimpiar.addActionListener(e -> limpiarCampos());

        setVisible(true);
    }

    private void mostrarResumen() {
        String servicios = "";
        if (chkAudifonos.isSelected()) servicios += "Audífonos ";
        if (chkManta.isSelected()) servicios += "Manta ";
        if (chkRevistas.isSelected()) servicios += "Revistas ";

        String piso = rbPrimerPiso.isSelected() ? "1er Piso" : "2do Piso";

        String servicioLista = listaServicio.getSelectedValue();
        if (servicioLista == null) servicioLista = "No seleccionado";

        String resumen =
                "Nombre: " + txtNombre.getText() +
                "\nDNI: " + txtDNI.getText() +
                "\nFecha de viaje: " + txtFecha.getText() +
                "\nPiso: " + piso +
                "\nOrigen: " + cbOrigen.getSelectedItem() +
                "\nDestino: " + cbDestino.getSelectedItem() +
                "\nServicios adicionales: " + servicios +
                "\nCalidad de servicio: " + servicioLista;

        JOptionPane.showMessageDialog(this, resumen, "Resumen de Pasaje", JOptionPane.INFORMATION_MESSAGE);
    }

    private void limpiarCampos() {
        txtNombre.setText("");
        txtDNI.setText("");
        txtFecha.setText("dd/mm/aaaa");

        chkAudifonos.setSelected(false);
        chkManta.setSelected(false);
        chkRevistas.setSelected(false);

        rbPrimerPiso.setSelected(true);

        cbOrigen.setSelectedIndex(0);
        cbDestino.setSelectedIndex(0);

        listaServicio.clearSelection();
    }
}

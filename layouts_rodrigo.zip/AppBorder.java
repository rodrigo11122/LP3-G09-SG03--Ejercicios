import javax.swing.JFrame;

public class AppBorder {
    public static void main(String[] args) {
        MarcoBorderLayout ventana = new MarcoBorderLayout();
        ventana.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        ventana.setSize(300, 200);
        ventana.setVisible(true);
    }
}

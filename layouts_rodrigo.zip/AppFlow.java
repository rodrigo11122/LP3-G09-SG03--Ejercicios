import javax.swing.JFrame;

public class AppFlow {
    public static void main(String[] args) {
        MarcoFlowLayout ventana = new MarcoFlowLayout();
        ventana.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        ventana.setSize(300, 100);
        ventana.setVisible(true);
    }
}

import javax.swing.JFrame;

public class AppGrid {
    public static void main(String[] args) {
        MarcoGridLayout ventana = new MarcoGridLayout();
        ventana.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        ventana.setSize(350, 200);
        ventana.setVisible(true);
    }
}
